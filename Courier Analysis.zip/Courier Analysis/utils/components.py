"""
Reusable Streamlit UI components for the Courier Analysis application.

Responsibilities
----------------
- Page headings
- Section headings
- Notes and information boxes
- Status messages
- Metric rows
- Empty-state messages
- Dividers
- Cost-basis explanations

This module must not contain:
- Business calculations
- CSV loading
- Session-state logic
- Page configuration
"""

from __future__ import annotations

from html import escape
from typing import Any

import streamlit as st


# =========================================================
# INTERNAL HELPERS
# =========================================================
def _safe_html_text(
    value: Any,
) -> str:
    """
    Convert a value into safe HTML text.
    """

    if value is None:
        return ""

    return escape(
        str(value)
    )


def _display_title(
    title: str,
    icon: str = "",
) -> str:
    """
    Combine an optional icon with a title.
    """

    clean_title = _safe_html_text(
        title
    )

    clean_icon = _safe_html_text(
        icon
    )

    if clean_icon:
        return (
            f"{clean_icon} {clean_title}"
        )

    return clean_title


# =========================================================
# PAGE HEADER
# =========================================================
def page_header(
    title: str,
    subtitle: str = "",
    icon: str = "",
) -> None:
    """
    Display the main page title and optional subtitle.
    """

    st.markdown(
        f"""
        <div style="
            text-align:center;
            margin-top:0.25rem;
            margin-bottom:0.25rem;
        ">
            <div style="
                color:#1E3A8A;
                font-size:38px;
                font-weight:700;
                line-height:1.2;
            ">
                {_display_title(title, icon)}
            </div>
        </div>
        """,
        unsafe_allow_html=True,
    )

    if subtitle:
        st.markdown(
            f"""
            <div style="
                text-align:center;
                color:#64748B;
                font-size:16px;
                margin-bottom:1.5rem;
            ">
                {_safe_html_text(subtitle)}
            </div>
            """,
            unsafe_allow_html=True,
        )


# =========================================================
# SECTION TITLES
# =========================================================
def section_title(
    title: str,
    icon: str = "",
) -> None:
    """
    Display a major section heading.
    """

    st.markdown(
        f"""
        <div style="
            color:#1E3A8A;
            font-size:24px;
            font-weight:700;
            margin-top:1.5rem;
            margin-bottom:0.75rem;
            padding-bottom:0.35rem;
            border-bottom:2px solid #DBEAFE;
        ">
            {_display_title(title, icon)}
        </div>
        """,
        unsafe_allow_html=True,
    )


def subsection_title(
    title: str,
    icon: str = "",
) -> None:
    """
    Display a smaller subsection heading.
    """

    st.markdown(
        f"""
        <div style="
            color:#334155;
            font-size:18px;
            font-weight:700;
            margin-top:1rem;
            margin-bottom:0.5rem;
        ">
            {_display_title(title, icon)}
        </div>
        """,
        unsafe_allow_html=True,
    )


# =========================================================
# DIVIDER
# =========================================================
def divider() -> None:
    """
    Display a horizontal divider.
    """

    st.divider()


# =========================================================
# NOTE BOX
# =========================================================
def note_box(
    title: str,
    message: str,
    icon: str = "📝",
) -> None:
    """
    Display a standard explanatory note.
    """

    st.markdown(
        f"""
        <div style="
            background:#F8FAFC;
            border:1px solid #CBD5E1;
            border-left:5px solid #64748B;
            border-radius:8px;
            padding:14px 16px;
            margin:10px 0 16px 0;
        ">
            <div style="
                color:#334155;
                font-size:15px;
                font-weight:700;
                margin-bottom:5px;
            ">
                {_display_title(title, icon)}
            </div>

            <div style="
                color:#475569;
                font-size:14px;
                line-height:1.6;
            ">
                {_safe_html_text(message)}
            </div>
        </div>
        """,
        unsafe_allow_html=True,
    )


# =========================================================
# INFORMATION BOX
# =========================================================
def info_box(
    title: str,
    message: str,
    icon: str = "ℹ️",
) -> None:
    """
    Display an informational message box.
    """

    st.markdown(
        f"""
        <div style="
            background:#EFF6FF;
            border:1px solid #BFDBFE;
            border-left:5px solid #2563EB;
            border-radius:8px;
            padding:14px 16px;
            margin:10px 0 16px 0;
        ">
            <div style="
                color:#1E3A8A;
                font-size:15px;
                font-weight:700;
                margin-bottom:5px;
            ">
                {_display_title(title, icon)}
            </div>

            <div style="
                color:#334155;
                font-size:14px;
                line-height:1.6;
            ">
                {_safe_html_text(message)}
            </div>
        </div>
        """,
        unsafe_allow_html=True,
    )


# =========================================================
# STATUS BOX
# =========================================================
def status_box(
    status: str,
    title: str,
    message: str,
) -> None:
    """
    Display a status-based Streamlit message.

    Supported values:
    - success
    - warning
    - error
    - info
    """

    normalised_status = (
        str(status)
        .strip()
        .lower()
    )

    content = (
        f"**{title}**\n\n{message}"
    )

    if normalised_status == "success":
        st.success(
            content
        )

    elif normalised_status == "warning":
        st.warning(
            content
        )

    elif normalised_status == "error":
        st.error(
            content
        )

    else:
        st.info(
            content
        )


# =========================================================
# EMPTY STATE
# =========================================================
def empty_state(
    title: str,
    message: str,
    icon: str = "📭",
) -> None:
    """
    Display an empty-state card.
    """

    st.markdown(
        f"""
        <div style="
            background:#F8FAFC;
            border:1px dashed #94A3B8;
            border-radius:10px;
            padding:26px 20px;
            text-align:center;
            margin:12px 0 16px 0;
        ">
            <div style="
                font-size:34px;
                margin-bottom:8px;
            ">
                {_safe_html_text(icon)}
            </div>

            <div style="
                color:#334155;
                font-size:18px;
                font-weight:700;
                margin-bottom:6px;
            ">
                {_safe_html_text(title)}
            </div>

            <div style="
                color:#64748B;
                font-size:14px;
                line-height:1.6;
            ">
                {_safe_html_text(message)}
            </div>
        </div>
        """,
        unsafe_allow_html=True,
    )


# =========================================================
# METRIC CARDS
# =========================================================
def metric_cards(
    metrics: list[dict[str, Any]],
    columns: int | None = None,
) -> None:
    """
    Display a row of Streamlit metrics.

    Example
    -------
    metric_cards(
        [
            {
                "label": "Total Parcels",
                "value": "200,000",
            },
            {
                "label": "Total Cost",
                "value": "RM 150,000",
                "delta": "-3.2%",
            },
        ]
    )
    """

    if not metrics:
        return

    column_count = (
        columns
        if columns is not None
        else len(metrics)
    )

    column_count = max(
        int(column_count),
        1,
    )

    metric_columns = st.columns(
        column_count
    )

    for index, metric in enumerate(
        metrics
    ):
        target_column = metric_columns[
            index % column_count
        ]

        with target_column:
            st.metric(
                label=metric.get(
                    "label",
                    "",
                ),
                value=metric.get(
                    "value",
                    "",
                ),
                delta=metric.get(
                    "delta",
                    None,
                ),
                help=metric.get(
                    "help",
                    None,
                ),
            )


# =========================================================
# COST BASIS
# =========================================================
def cost_basis(
    title: str = "Cost Analysis Basis",
    message: str | None = None,
    items: list[str] | None = None,
    basis: str | None = None,
) -> None:
    """
    Display an explanation of the calculation or cost basis.

    Supports several calling styles:

    cost_basis()

    cost_basis(
        title="Shipment Cost Basis",
        message="The shipment assumptions are used throughout the app."
    )

    cost_basis(
        items=[
            "Per shipment",
            "Per parcel",
            "Per kilogram",
        ]
    )

    cost_basis(
        basis="Per shipment"
    )
    """

    default_items = [
        "Per shipment",
        "Per parcel",
        "Per kilogram",
        "Per cubic metre",
        "Per vehicle",
        "Per kilometre",
    ]

    selected_items = (
        items
        if items is not None
        else default_items
    )

    if basis:
        selected_items = [
            basis
        ]

    message_html = ""

    if message:
        message_html = f"""
            <div style="
                color:#475569;
                font-size:13px;
                line-height:1.6;
                margin-bottom:8px;
            ">
                {_safe_html_text(message)}
            </div>
        """

    items_html = "".join(
        f"""
        <li style="margin-bottom:3px;">
            {_safe_html_text(item)}
        </li>
        """
        for item in selected_items
    )

    st.markdown(
        f"""
        <div style="
            background:#FFFBEB;
            border:1px solid #FDE68A;
            border-left:5px solid #D97706;
            border-radius:8px;
            padding:12px 15px;
            margin:10px 0 16px 0;
        ">
            <div style="
                color:#92400E;
                font-size:14px;
                font-weight:700;
                margin-bottom:6px;
            ">
                📌 {_safe_html_text(title)}
            </div>

            {message_html}

            <ul style="
                color:#78350F;
                font-size:13px;
                line-height:1.5;
                margin:0;
                padding-left:20px;
            ">
                {items_html}
            </ul>
        </div>
        """,
        unsafe_allow_html=True,
    )